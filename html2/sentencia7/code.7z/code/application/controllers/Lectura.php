<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Lectura extends CI_Controller {


	public function index()
	{
		$datos["Nombre"]="Moises";
		$datos["Apellido"]="Silva";
		$this->load->model("Academico_model");
		$filas = $this->Academico_model->alumnos();
		$datos["filas"]=$filas;
		$this->load->view('view_lectura', $datos);
	}
	
	public function index2()
	{
		$datos["Nombre"]="Moises";
		$datos["Apellido"]="Silva";
		$this->load->model("Academico_model");
		$filas = $this->Academico_model->alumno('32');
		$datos["filas"]=$filas;
		$this->load->view('view_lectura', $datos);
	}
}
